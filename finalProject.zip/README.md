There also is a zip file.

npm install  
npx prisma generate  
npx prisma db push --force-reset  
npx prisma db seed  
npm run dev (separate terminal)  
npm run test

Should give the proper results ;)
